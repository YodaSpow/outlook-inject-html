"use strict";

const START_MESSAGE = "outlook-compose-html:start";
const STATUS_MESSAGE = "outlook-compose-html:status";

const STATES = Object.freeze({
  working: { badge: "…", color: "#5a217f", title: "Outlook Compose HTML — working" },
  success: { badge: "OK", color: "#18794e", title: "Outlook Compose HTML — inserted successfully" },
  failure: { badge: "ERR", color: "#b42318", title: "Outlook Compose HTML — insertion failed" },
  cancelled: { badge: "", color: "#5a217f", title: "Outlook Compose HTML — choose a sealed HTML file" },
});

async function showStatus(tabId, state, detail) {
  if (!Number.isInteger(tabId)) return;
  const status = STATES[state] || STATES.failure;
  await Promise.all([
    chrome.action.setBadgeText({ tabId, text: status.badge }),
    chrome.action.setBadgeBackgroundColor({ tabId, color: status.color }),
    chrome.action.setTitle({ tabId, title: detail ? `${status.title}: ${detail}` : status.title }),
  ]);
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!Number.isInteger(tab.id)) return;
  await showStatus(tab.id, "working", "Waiting for file selection");
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { type: START_MESSAGE });
    if (!response || response.accepted !== true) {
      await showStatus(tab.id, "failure", response && response.detail ? response.detail : "Open an Outlook compose body first");
    }
  } catch (_error) {
    await showStatus(tab.id, "failure", "Open outlook.live.com and an editable message body first");
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (!message || message.type !== STATUS_MESSAGE) return false;
  const tabId = sender.tab && sender.tab.id;
  showStatus(tabId, message.state, message.detail).catch(() => {});
  return false;
});
