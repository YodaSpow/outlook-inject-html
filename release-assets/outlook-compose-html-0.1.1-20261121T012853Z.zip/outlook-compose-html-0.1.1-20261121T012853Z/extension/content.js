(function () {
  "use strict";

  const Contracts = globalThis.OutlookComposeContracts;
  const START_MESSAGE = "outlook-compose-html:start";
  const STATUS_MESSAGE = "outlook-compose-html:status";
  const PASTE_WAIT_MS = 1500;
  let operationActive = false;

  function report(state, detail) {
    chrome.runtime.sendMessage({ type: STATUS_MESSAGE, state, detail }).catch(() => {});
  }

  function findComposeBody() {
    const candidates = document.querySelectorAll(Contracts.BODY_SELECTOR);
    return Array.from(candidates).find(Contracts.isOutlookComposeBody) || null;
  }

  async function snapshotClipboard() {
    const items = await navigator.clipboard.read();
    const copies = [];
    for (const item of items) {
      const payload = {};
      for (const type of item.types) payload[type] = await item.getType(type);
      if (Contracts.hasClipboardPayload(payload)) {
        copies.push(new ClipboardItem(payload, { presentationStyle: item.presentationStyle }));
      }
    }
    return copies;
  }

  async function restoreClipboard(items) {
    if (items.length) {
      await navigator.clipboard.write(items);
      return;
    }
    await navigator.clipboard.writeText("");
  }

  function placeCaretAtEnd(target) {
    target.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(target);
    range.collapse(false);
    selection.removeAllRanges();
    selection.addRange(range);
  }

  function waitForEditorChange(target, before) {
    if (target.innerHTML !== before) return Promise.resolve();
    return new Promise((resolve) => {
      let settled = false;
      const observer = new MutationObserver(() => finish());
      const finish = () => {
        if (settled) return;
        settled = true;
        observer.disconnect();
        resolve();
      };
      observer.observe(target, { attributes: true, childList: true, characterData: true, subtree: true });
      window.setTimeout(finish, PASTE_WAIT_MS);
    });
  }

  async function insertSealedHtml(file, target) {
    const source = await file.text();
    if (!source.trim()) throw new Error("The selected HTML file is empty.");

    const previousClipboard = await snapshotClipboard();
    const before = target.innerHTML;
    let pasteAccepted = false;
    let restoreError = null;

    try {
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/html": new Blob([source], { type: "text/html" }),
          "text/plain": new Blob([""], { type: "text/plain" }),
        }),
      ]);
      placeCaretAtEnd(target);
      pasteAccepted = document.execCommand("paste");
      await waitForEditorChange(target, before);
    } finally {
      try {
        await restoreClipboard(previousClipboard);
      } catch (error) {
        restoreError = error;
      }
    }

    const evidence = Contracts.insertionEvidence(before, target.innerHTML, pasteAccepted);
    if (!evidence.inserted) throw new Error("Outlook did not accept the trusted HTML paste.");
    if (!target.isConnected || !Contracts.isOutlookComposeBody(target)) {
      throw new Error("The Outlook compose body changed before insertion completed.");
    }
    if (restoreError) throw new Error("HTML was inserted, but the previous clipboard could not be restored.");
    return evidence;
  }

  function chooseFile(target) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".html,.htm,text/html";
    input.hidden = true;
    document.documentElement.append(input);

    const finish = () => {
      operationActive = false;
      input.remove();
    };

    input.addEventListener("cancel", () => {
      finish();
      report("cancelled", "No file selected.");
    }, { once: true });

    input.addEventListener("change", async () => {
      const file = input.files && input.files[0];
      if (!file) {
        finish();
        report("cancelled", "No file selected.");
        return;
      }
      if (!Contracts.isSupportedHtmlFile(file)) {
        finish();
        report("failure", "Choose a local .html or .htm file.");
        return;
      }

      report("working", `Inserting ${file.name}…`);
      try {
        const evidence = await insertSealedHtml(file, target);
        report("success", `Inserted ${file.name} (${evidence.afterLength - evidence.beforeLength} editor characters added).`);
      } catch (error) {
        report("failure", error instanceof Error ? error.message : "HTML insertion failed.");
      } finally {
        finish();
      }
    }, { once: true });

    input.click();
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || message.type !== START_MESSAGE) return false;
    if (operationActive) {
      sendResponse({ accepted: false, detail: "A file selection is already open." });
      return false;
    }
    const target = findComposeBody();
    if (!target) {
      sendResponse({ accepted: false, detail: "Open an Outlook message compose body first." });
      return false;
    }
    operationActive = true;
    chooseFile(target);
    sendResponse({ accepted: true });
    return false;
  });
})();
